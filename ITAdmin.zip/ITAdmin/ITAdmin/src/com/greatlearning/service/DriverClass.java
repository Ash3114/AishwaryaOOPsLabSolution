package com.greatlearning.service;

import java.util.Scanner;

import com.greatlearning.module.Employee;


public class DriverClass {
	
	public static void main(String[] args) {
		Employee employee = new Employee("Aishwarya", "S");
		
		CredentialsService credentialService = new CredentialsService();
		
		String generatedEmail;
		char[] generatedPassword;
		
		System.out.println("Please enter the department from the following");
		System.out.println("1.Technical");
		System.out.println("2.Admin");
		System.out.println("3.Human Resources");
		System.out.println("4.Legal");
		
		Scanner sn=new Scanner(System.in);
		
		int option=sn.nextInt();
		
		if(option==1) {
			generatedEmail=credentialService.generateEmail(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "technical");
			generatedPassword=credentialService.generatePassword();
			credentialService.showCredentials(employee, generatedEmail, generatedPassword);
			
		}
		else if(option==2) {
			generatedEmail=credentialService.generateEmail(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "admin");
			generatedPassword=credentialService.generatePassword();
			credentialService.showCredentials(employee, generatedEmail, generatedPassword);
		}
		else if(option==3) {
			generatedEmail=credentialService.generateEmail(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "hr");
			generatedPassword=credentialService.generatePassword();
			credentialService.showCredentials(employee, generatedEmail, generatedPassword);
		}
		else if(option==4) {
			generatedEmail=credentialService.generateEmail(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "legal");
			generatedPassword=credentialService.generatePassword();
			credentialService.showCredentials(employee, generatedEmail, generatedPassword);
		}
		else {
			System.out.println("Please enter a valid option");
		}
		sn.close();
	}

}
