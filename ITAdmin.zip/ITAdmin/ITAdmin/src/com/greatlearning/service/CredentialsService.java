package com.greatlearning.service;

import java.util.Random;

import com.greatlearning.module.Employee;

public class CredentialsService {

	public char[] generatePassword(){
		
		char[] password = new char[8];
		
		String capitalLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String smallLetters = "abcdefghijklmnopqrstuvwxyz";
		String numbers = "01234567899";
		String specialCharacters="!@#$%^&*_+-/.?<>";
		
		String val=capitalLetters+smallLetters+numbers+specialCharacters;
		
		Random num=new Random();
		
		password[0]=capitalLetters.charAt(num.nextInt(capitalLetters.length()));
		password[1]=smallLetters.charAt(num.nextInt(smallLetters.length()));
		password[2]=numbers.charAt(num.nextInt(numbers.length()));
		password[3]=specialCharacters.charAt(num.nextInt(specialCharacters.length()));
		
		for(int i=4;i<8;i++) {
			password[i]=val.charAt(num.nextInt(val.length()));
		}
		
		return password;
		
	}
	
	public String generateEmail(String FirstName, String LastName, String Department) {
		StringBuffer sb=new StringBuffer();
		sb.append(FirstName);
		sb.append(LastName);
		sb.append("@");
		sb.append(Department);
		sb.append(".abc.com");
		
		return sb.toString();
	}
	
	public void showCredentials(Employee employee, String email, char[] generatePassword) {
		System.out.println("Dear "+employee.getFirstName()+ " Your generated creadentials are as follows:");
		System.out.println("Email -->"+email+" ");
		System.out.println(generatePassword);
	
		
	}
}
